window.onload = function() {

	console.log(utils.roundToPlaces(Math.PI, 1));
	console.log(utils.roundToPlaces(Math.PI, 3));
	console.log(utils.roundToPlaces(Math.PI, 5));

};