window.onload = function() {

	console.log(utils.roundToPlaces(123456789, -1));
	console.log(utils.roundToPlaces(123456789, -2));
	console.log(utils.roundToPlaces(123456789, -3));

};