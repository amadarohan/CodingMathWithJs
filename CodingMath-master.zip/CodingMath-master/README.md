CodingMath
==========

This repo will house any applicable files from the Coding Math videos.

Site: http://codingmath.com

YouTube: http://www.youtube.com/user/codingmath

Support: http://www.patreon.com/codingmath
